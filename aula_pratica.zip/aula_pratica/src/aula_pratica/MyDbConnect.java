package aula_pratica;

import java.sql.*;

public class MyDbConnect {
	static PreparedStatement ps;
	static ResultSet rs;
	
	public static void main(String[] args){
		try{
			Connection conexao = DriverManager.getConnection("jdbc:mysql://localhost:3306/demoDb", "root", "aluno");
			System.out.println("Conectado com a base de dados!");
			
			ps = conexao.prepareStatement("insert into estudante value(?,?,?)");
			ps.setString(1, "1");
			ps.setString(2, "Aluno");
			ps.setString(3, "ADS");
			ps.executeUpdate();
			ps.setString(1, "2");
			ps.setString(2, "Aluno");
			ps.setString(3, "ADS");
			ps.executeUpdate();
			ps.setString(1, "3");
			ps.setString(2, "Aluno");
			ps.setString(3, "ADS");
			ps.executeUpdate();
			System.out.println("Dados inseridos!");
			
			
			ps = conexao.prepareStatement("update estudante set CURSO=? where matricula=?");
			ps.setString(1, "Informatica");
			ps.setString(2, "2");
			ps.executeUpdate();
			System.out.println("Dados atualizados");
			
			ps = conexao.prepareStatement("select * from estudante");
			rs = ps.executeQuery();
			
			ps = conexao.prepareStatement("delete from estudante where matricula=?");
			ps.setString(1, "3");
			ps.executeUpdate();
			System.out.println("Dados apagados com sucesso.");
			
			
			ps = conexao.prepareStatement("select * from estudante");
			rs = ps.executeQuery();
			
			while(rs.next()){
				String matricula = rs.getString("MATRICULA");
				String nome = rs.getString("NOME");
				String curso = rs.getString("CURSO");
				
				System.out.println(matricula + " | " + nome + "  |  " + curso);
			}
			
		} catch (SQLException e) {
			System.out.println("Erro ao conectar na base de dados.");
		}
	}
}
