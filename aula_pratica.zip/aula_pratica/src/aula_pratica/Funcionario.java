package aula_pratica;

import java.sql.*;


public class Funcionario {
	private static PreparedStatement ps;
	private static ResultSet rs;
	private static Statement st;
	
	
	public static void main(String[] args) throws ClassNotFoundException{
		Connection conn = AbrirConexao();
		CriarBdFuncionarios(conn);
		

		String nomeUsu = "otavio_tursi";
		String usuarioUsu = "otavio";
		String senhaUsu = "senhaDoOtavio";
		InserirFuncionarios(conn, nomeUsu, usuarioUsu, senhaUsu);
		DeletarFuncionarios(conn, 5);
		AtualizarFuncionarios(conn, 7, "teste Att", "testeAtt", "senhaatt");


	}
	
	public static void InserirFuncionarios(Connection conn, String nome, String usuario, String senha){
		try {
			String comando = String.format("INSERT INTO `funcionarios`( `nome`, `usuario`, `senha`) VALUES ('"+nome+"','"+usuario+"','"+senha+"')");
			st.execute(comando);
			System.out.println("Funcionario inserido!");
		} catch (SQLException e) {
			System.out.println("Erro ao inserir funcionarios."+ e.toString());
		}
	}
	public static void AtualizarFuncionarios(Connection conn, int id, String nome, String usuario, String senha){
		try {
			String comando = String.format("UPDATE `funcionarios` SET  `nome`='"+nome+"', `usuario`='"+usuario+"', `senha`='"+senha+"' WHERE id="+id+" ");
			st.execute(comando);
			System.out.println("Funcionario atualizado!");
		} catch (SQLException e) {
			System.out.println("Erro ao atualizar funcionarios."+ e.toString());
		}
	}
	
	public static void DeletarFuncionarios(Connection conn, int id){
		try {
			String comando = String.format("DELETE FROM `funcionarios` WHERE id="+id+" ");
			st.execute(comando);
			System.out.println("Funcionario deletado!");
		} catch (SQLException e) {
			System.out.println("Erro ao deletar funcionarios."+ e.toString());
		}
	}
	
	public static Connection AbrirConexao(){
		Connection conn = null;
		try {
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/func", "root", null);
			System.out.println("Conectado com a base de dados!");
		} catch (SQLException e) {
			System.out.println("Erro ao conectar na base de dados."+ e.toString());
		}
		return conn;
	}
	
	public static void CriarBdFuncionarios(Connection conn){
		try {
			String query = "create table if not exists funcionarios (id integer not null AUTO_INCREMENT, nome varchar(30) not null, usuario varchar(30), senha varchar(30),  PRIMARY KEY(id))";
			st = conn.createStatement();
			st.execute(query);
			System.out.println("BD FUNCIONARIOS CRIADO!");
		} catch (SQLException e) {
			System.out.println("Erro ao criar bd funcionarios.");
			e.printStackTrace();
		}
	}
}
