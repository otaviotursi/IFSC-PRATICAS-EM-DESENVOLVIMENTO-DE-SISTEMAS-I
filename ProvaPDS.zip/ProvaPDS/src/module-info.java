module ProvaPDS {
	requires java.desktop;
}