

public class ComandaModel {
	public long codigoId;
	public long codigoMesa;
	public long produto; //comida ou bebida
	public String responsavel;
}
