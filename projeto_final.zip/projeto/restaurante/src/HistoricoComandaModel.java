import java.sql.Date;

public class HistoricoComandaModel {
	public long codigoMesa;
	public String produtos;
	public String statusPagamento;
	public Date data;
	public double valor;
}
