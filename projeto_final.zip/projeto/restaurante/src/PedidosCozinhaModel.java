

public class PedidosCozinhaModel {
	public long codigoId;
	public long codigoProduto;
	public long codigoMesa;
	public String status;
}
