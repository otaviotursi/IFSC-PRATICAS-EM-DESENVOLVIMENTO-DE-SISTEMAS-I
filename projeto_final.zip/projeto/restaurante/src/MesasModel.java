

public class MesasModel {
	public long codigoMesa;
	public String status;
}
