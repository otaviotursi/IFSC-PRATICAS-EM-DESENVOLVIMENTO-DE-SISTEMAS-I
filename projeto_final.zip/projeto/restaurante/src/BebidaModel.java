

public class BebidaModel {
	public long codigo;
	public String nome;
	public Double preco;
	public String descricao;
	public boolean alcoolico;
}
