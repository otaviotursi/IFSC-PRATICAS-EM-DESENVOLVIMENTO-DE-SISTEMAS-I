

public class FuncionariosModel {
	public long codigo;
	public String nome;
	public String cargo;
}
