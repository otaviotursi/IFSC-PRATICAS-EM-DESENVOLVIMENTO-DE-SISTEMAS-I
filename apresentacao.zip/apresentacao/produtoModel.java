package apresentacao;

public class produtoModel {
	public long codigo;
	public String nome;
	public Double preco;
	public long quantidade;
}
