package apresentacao;

import java.sql.*;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;



/*Sistema para gerenciamento de estoque*/

public class GerenciadorEstoque extends estoqueBD implements ActionListener {
	

	JButton buttonInserirProduto;
	JButton buttonExcluirProduto;
	JButton buttonAlterarProduto;
	JButton buttonConsultarProduto;
	JTextField idProduto;
	JTextField nomeProduto;
	JTextField quantidadeProduto;
	JTextField precoProduto;
	private produtoModel produto;
	
	public GerenciadorEstoque() {
		JFrame frame = new JFrame("Estoque de produtos - Mercado");
		frame.setSize(350,350);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		JPanel panel = new JPanel();
		frame.add(panel);

		JPanel panel1 = new JPanel();
		panel1.setSize(250,150);
		panel1.setLayout(new BorderLayout());
		
		
		buttonInserirProduto = new JButton("Inserir");
		buttonInserirProduto.addActionListener(this);
		panel1.add(buttonInserirProduto, BorderLayout.WEST);
		
		buttonExcluirProduto = new JButton("Excluir");
		buttonExcluirProduto.addActionListener(this);
		panel1.add(buttonExcluirProduto, BorderLayout.CENTER);

		buttonAlterarProduto = new JButton("Alterar");
		buttonAlterarProduto.addActionListener(this);
		panel1.add(buttonAlterarProduto, BorderLayout.EAST);
		
		buttonConsultarProduto = new JButton("Consultar");
		buttonConsultarProduto.addActionListener(this);
		panel1.add(buttonConsultarProduto, BorderLayout.SOUTH);
		
		panel.add(panel1, BorderLayout.NORTH);


		JPanel panel2 = new JPanel();
		panel2.setSize(250,250);
		panel2.setLayout(new BoxLayout(panel2, BoxLayout.Y_AXIS));
		
		nomeProduto = new JTextField (30);
		nomeProduto.setText("");
		panel2.add(nomeProduto);
		
		idProduto = new JTextField (30);
		idProduto.setText("");
		panel2.add(idProduto);
		
		quantidadeProduto = new JTextField (30);
		quantidadeProduto.setText("");
		panel2.add(quantidadeProduto, BorderLayout.CENTER);
		
		precoProduto = new JTextField (30);
		precoProduto.setText("");
		panel2.add(precoProduto, BorderLayout.SOUTH);
		
		panel.add(panel2, BorderLayout.SOUTH);
	}
	
	public static void main(String[] args){
		AbrirConexao();
		CriarBdProduto();
		MockarBdProduto();
		
		SwingUtilities.invokeLater(new Runnable() {
			@Override 
			public void run() {
				new GerenciadorEstoque();
			}
		});


	}

	@Override
	public void actionPerformed(ActionEvent arg) {
		String comando = arg.getActionCommand();
		System.out.println("comando: "+comando);
		
		produto.nome = this.nomeProduto.getText();
		produto.preco = Double.parseDouble(this.precoProduto.getText());
		produto.quantidade= Long.parseLong(this.quantidadeProduto.getText());
		produto.codigo = Integer.parseInt(this.idProduto.getText());
		
		switch (comando) {
			case "Inserir":
				InserirProduto(produto);
				break;
			case "Excluir":
				DeletarProduto(produto.codigo);
				break;
			case "Alterar":
				AtualizarProduto(produto);
				break;
			case "Consultar":
				ConsultarProduto();
				break;
		}
		
	}
	
	
}
