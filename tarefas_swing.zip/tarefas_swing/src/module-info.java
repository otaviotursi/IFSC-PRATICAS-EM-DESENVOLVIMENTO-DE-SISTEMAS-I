module tarefas_swing {
	requires java.desktop;
}